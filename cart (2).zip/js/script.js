
const PRODUCTS = [
{id:1,brand:"Apple",name:"iPhone 15 Pro",cat:"electronics",price:999,old:1099,rating:4.9,img:"https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=900&q=85",desc:"Titanium design, A17 Pro chip and a pro camera system."},
{id:2,brand:"Apple",name:"MacBook Air M3",cat:"electronics",price:1099,old:1199,rating:4.8,img:"https://images.unsplash.com/photo-1517336714739-489689fd1ca8?auto=format&fit=crop&w=900&q=85",desc:"Lightweight performance with the Apple M3 chip."},
{id:3,brand:"Sony",name:"WH-1000XM5",cat:"electronics",price:349,old:399,rating:4.8,img:"https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=900&q=85",desc:"Premium wireless noise-cancelling headphones."},
{id:4,brand:"Canon",name:"EOS R50",cat:"electronics",price:679,old:749,rating:4.7,img:"https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=900&q=85",desc:"Compact mirrorless camera for creators and travel."},
{id:5,brand:"Nike",name:"Air Max 270",cat:"footwear",price:150,old:180,rating:4.7,img:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=85",desc:"Iconic lifestyle sneakers with visible Air cushioning."},
{id:6,brand:"Adidas",name:"Ultraboost Light",cat:"footwear",price:180,old:210,rating:4.6,img:"https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=900&q=85",desc:"Responsive running shoes built for everyday mileage."},
{id:7,brand:"Ray-Ban",name:"Wayfarer Classic",cat:"accessories",price:163,old:190,rating:4.8,img:"https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=900&q=85",desc:"The unmistakable original Wayfarer silhouette."},
{id:8,brand:"Fjällräven",name:"Kånken Backpack",cat:"accessories",price:90,old:110,rating:4.7,img:"https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=85",desc:"A practical everyday backpack with Scandinavian design."},
{id:9,brand:"Levi's",name:"501 Original Jeans",cat:"fashion",price:79,old:99,rating:4.6,img:"https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&w=900&q=85",desc:"The original straight-fit jean, designed for decades."},
{id:10,brand:"Nike",name:"Sportswear Hoodie",cat:"fashion",price:65,old:80,rating:4.5,img:"https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=900&q=85",desc:"Soft everyday fleece with a relaxed athletic fit."},
{id:11,brand:"Apple",name:"Watch Series 9",cat:"electronics",price:399,old:449,rating:4.8,img:"https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=900&q=85",desc:"Powerful smartwatch with health and fitness features."},
{id:12,brand:"Adidas",name:"Samba OG",cat:"footwear",price:100,old:120,rating:4.8,img:"https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&w=900&q=85",desc:"Low-profile terrace-inspired classic for everyday style."}
];

const money=n=>"$"+n.toLocaleString();
const getCart=()=>JSON.parse(localStorage.getItem("shopease-cart")||"[]");
const setCart=c=>{localStorage.setItem("shopease-cart",JSON.stringify(c));updateCartCount();};
const getWish=()=>JSON.parse(localStorage.getItem("shopease-wish")||"[]");
const setWish=w=>localStorage.setItem("shopease-wish",JSON.stringify(w));

function toast(msg){let t=document.querySelector(".toast");if(!t){t=document.createElement("div");t.className="toast";document.body.appendChild(t)}t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),1800)}
function updateCartCount(){let n=getCart().reduce((a,b)=>a+b.qty,0);document.querySelectorAll(".cart-count").forEach(e=>e.textContent=n)}
function addToCart(id){let c=getCart(),x=c.find(i=>i.id===id);x?x.qty++:c.push({id,qty:1});setCart(c);toast("Added to bag");}
function removeFromCart(id){setCart(getCart().filter(x=>x.id!==id));renderCart()}
function changeQty(id,d){let c=getCart(),x=c.find(i=>i.id===id);if(x){x.qty+=d;if(x.qty<=0)c=c.filter(i=>i.id!==id)}setCart(c);renderCart()}
function toggleWish(id){let w=getWish();w=w.includes(id)?w.filter(x=>x!==id):[...w,id];setWish(w);renderProducts();toast(w.includes(id)?"Saved to wishlist":"Removed from wishlist")}
function productCard(p){
 let wish=getWish().includes(p.id);
 return `<article class="product-card"><div class="product-media"><span class="badge">${p.old>p.price?"SALE":"NEW"}</span><button class="heart ${wish?"active":""}" onclick="toggleWish(${p.id})">${wish?"♥":"♡"}</button><a href="product.html?id=${p.id}"><img src="${p.img}" alt="${p.name}"></a></div><div class="product-info"><div class="brand">${p.brand}</div><h3>${p.name}</h3><div class="rating">★★★★★ <span> ${p.rating}</span></div><div class="price">${money(p.price)} <span class="old">${money(p.old)}</span></div><div class="card-actions"><button class="small-btn" onclick="addToCart(${p.id})">Add to Bag</button><a class="small-btn secondary" href="product.html?id=${p.id}">View</a></div></div></article>`
}
function renderProducts(){
 let el=document.querySelector("#product-grid");if(!el)return;
 let list=[...PRODUCTS],cat=document.body.dataset.category||"";
 if(cat && cat!=="deals")list=list.filter(p=>p.cat===cat); if(cat==="deals")list=list.filter(p=>p.old>p.price);
 let q=document.querySelector("#product-search")?.value.toLowerCase()||"";
 if(q)list=list.filter(p=>(p.name+" "+p.brand+" "+p.cat).toLowerCase().includes(q));
 let sort=document.querySelector("#sort")?.value;
 if(sort==="low")list.sort((a,b)=>a.price-b.price);if(sort==="high")list.sort((a,b)=>b.price-a.price);if(sort==="rating")list.sort((a,b)=>b.rating-a.rating);
 el.innerHTML=list.length?list.map(productCard).join(""):`<div class="empty" style="grid-column:1/-1">No products match your search.</div>`;
}
function renderFeatured(){let e=document.querySelector("#featured-grid");if(e)e.innerHTML=PRODUCTS.slice(0,8).map(productCard).join("")}
function renderProduct(){
 let e=document.querySelector("#product-detail");if(!e)return;
 let id=Number(new URLSearchParams(location.search).get("id"))||1,p=PRODUCTS.find(x=>x.id===id)||PRODUCTS[0];
 e.innerHTML=`<div class="detail-image"><img src="${p.img}" alt="${p.name}"></div><div><div class="brand">${p.brand}</div><h1>${p.name}</h1><div class="rating">★★★★★ ${p.rating}</div><div class="detail-price">${money(p.price)} <span class="old">${money(p.old)}</span></div><p>${p.desc}</p><div class="qty"><button onclick="detailQty(-1)">−</button><span id="detail-qty">1</span><button onclick="detailQty(1)">+</button></div><button class="btn" onclick="addDetail(${p.id})">Add to Bag</button><button class="btn outline" style="margin-left:8px" onclick="toggleWish(${p.id})">♡ Wishlist</button><hr style="margin:35px 0;border:0;border-top:1px solid var(--line)"><p><b>Shipping:</b> Free standard delivery on qualifying orders.</p><p><b>Returns:</b> Easy returns within 30 days.</p></div>`;
}
function detailQty(d){let e=document.querySelector("#detail-qty");e.textContent=Math.max(1,Number(e.textContent)+d)}
function addDetail(id){let q=Number(document.querySelector("#detail-qty").textContent),c=getCart(),x=c.find(i=>i.id===id);x?x.qty+=q:c.push({id,qty:q});setCart(c);toast("Added to bag")}
function renderCart(){
 let el=document.querySelector("#cart-items");if(!el)return;let c=getCart();
 if(!c.length){el.innerHTML=`<div class="empty"><h2>Your bag is empty</h2><p>Discover something you'll love.</p><a class="btn" href="shop.html" style="margin-top:18px">Continue Shopping</a></div>`;document.querySelector("#subtotal").textContent="$0";return}
 let total=0;
 el.innerHTML=c.map(i=>{let p=PRODUCTS.find(x=>x.id===i.id);total+=p.price*i.qty;return `<div class="cart-item"><img src="${p.img}" alt="${p.name}"><div><div class="brand">${p.brand}</div><b>${p.name}</b><div class="qty"><button onclick="changeQty(${p.id},-1)">−</button><span>${i.qty}</span><button onclick="changeQty(${p.id},1)">+</button></div></div><div><b>${money(p.price*i.qty)}</b><br><button onclick="removeFromCart(${p.id})" style="background:none;color:var(--accent);margin-top:7px">Remove</button></div></div>`}).join("");
 document.querySelector("#subtotal").textContent=money(total);document.querySelector("#total").textContent=money(total);
}
function setup(){
 updateCartCount();renderFeatured();renderProducts();renderProduct();renderCart();
 document.querySelectorAll("#product-search").forEach(e=>e.addEventListener("input",renderProducts));
 document.querySelectorAll("#sort").forEach(e=>e.addEventListener("change",renderProducts));
 document.querySelectorAll(".mobile-menu").forEach(b=>b.addEventListener("click",()=>document.querySelector(".navlinks").classList.toggle("mobile-open")));
 document.querySelectorAll("form.demo").forEach(f=>f.addEventListener("submit",e=>{e.preventDefault();toast("Thanks! Your message was submitted.");f.reset()}));
}
document.addEventListener("DOMContentLoaded",setup);
